from regexp import Pattern, ReNode, retype
import networkx as nx
from symbols import Word, _Set,SetException
from components import State as st
from components import Transition as tr
from data_structure import Stacks,Queue,List
from utils import list_contain



class AutomateException(Exception):
    def __init__(self,msg) -> None:
        super().__init__(self)
        self.msg=msg
    
    def __str__(self) -> str:
        return self.msg

class Automate(nx.Graph):
    def __init__(self,s=_Set()):
        super().__init__()
        self.base_set=s
        self.states=[]
        self.transitions=list()
        self.finals=set()
        self.start=None
        self.labels=set()
        self.entries=set()
        

    def add_state(self, node_for_adding=st()):
        value=node_for_adding.label
        if node_for_adding.label in self.labels or node_for_adding.label == '':
            pass
        else:    
            self.states.append(node_for_adding)
            self.labels.add(node_for_adding.label)
            return super().add_node(node_for_adding,attr=value)
        
    def add_states_from(self, nodes_for_adding=[]):
        for elt in nodes_for_adding:
            self.add_state(elt)
    
    def print_states(self):
        print(self.labels)

    def get_state(self,n):
        for elt in self.states:
            if elt.label == n:
                return elt

    def alter_state(self,prev,n):
        s=self.get_state(prev)
        for elt in self.states:
            if elt==s:
                elt.label=n
        for elt in self.transitions:
            if elt.root == s:
                elt.root.label=n
        for elt in self.transitions:
            if elt.dest == s:
                elt.dest.label=n
        for elt in self.labels:
            if elt == prev:
                self.labels.remove(elt)
                self.labels.add(n)
        if s == self.start:
            self.start.label = n
        for elt in self.finals:
            if elt==s:
                elt.label = n
    
    def add_trans(self, u_of_edge=st(), v_of_edge=st(),weight={}):
        try:
            self.add_states_from([u_of_edge,v_of_edge])
            self.transitions.append(tr(u_of_edge,v_of_edge,weight))
            for elt in weight:
                if not self.base_set.contained(elt):
                    raise SetException('Value \''+elt+'\' provided in the label is not part of the symbols base set')
                else:
                    if not elt == '':
                        self.entries.add(elt)
        finally:
            pass
        return super().add_edge(u_of_edge, v_of_edge,attr=weight)

    def add_trans_from(self,l=[]):
        for elt in l:
            self.transitions.append(elt)
            for e in elt.label:
                if not e == '':
                    self.entries.add(e) 

    def view_trans(self):
        t=[]
        for elt in self.transitions:
            try:
                t.append((elt.root.label,elt.dest.label,elt.label))
            except AttributeError:
                t.append((elt.root.label,None,elt.label))
        print(t)

    def is_final(self,state):
        """Check wether a given state is a final state or not"""

        adj=[]
        for elt in self.transitions:
            if elt.root==state:
                adj.append(elt)
        for elt in adj:
            if elt.dest.label=='':
                return True
        return False
    
    def set_finals(self):
        """Setting up the Automate finals states"""
        for elt in self.states:
            if self.is_final(elt):
                self.finals.add(elt)
    
    def set_final(self,node=st()):
        self.add_trans(node)
        self.finals.add(node)
    
    def set_start(self,s=st()):
        """Setting up the DFA initial state"""
        self.start=s
        return s
    
    def get_final_trans(self):
        f=0
        for e in self.transitions:
            if e.dest.label == '':
                f=e 
        return f

    def unit_delta(self,state=st(),c=''):
        """Defining the elementary transition application inside the DFA"""

        for elt in self.transitions:
            if elt.root == state and c in elt.label:
                return elt.dest
    
    def delta(self,state=st(),u=Word()):
        if u.get_lenght()==1:
            return self.unit_delta(state,u.symbols[0])
        else:
            c=u.symbols[0]
            del(u.symbols[0])
            return self.delta(self.unit_delta(state,c),u)


    def is_complete_state(self,node):
        """"Test si un etat est 'complet', retourne les symboles manquant si ce dernier est
        non complet"""

        _entries=set()
        for elt in self.transitions:
            if elt.root == node:
                for e in elt.label:
                    _entries.add(e)
        if _entries.issuperset(self.entries):
            return True
        else:
            return self.entries.difference(_entries)
    
    def is_complete(self):
        """Teste si un automate est complet, retourne les etats non complets sinon"""

        uncompleted=[]
        for elt in self.states:
            if not self.is_complete_state(elt) == True:
                uncompleted.append(elt)
        if len(uncompleted) == 0:
            return True
        else:
            return uncompleted
    
    def set_complete(self):
        """Transforme un automate non complet en automate complet"""

        if self.is_complete() == True:
            pass
        else:
            uncompletes=self.is_complete()
            pit=st(100)
            self.add_state(pit)

            for elt in uncompletes:
                for e in self.is_complete_state(elt):
                    self.add_trans(elt,pit,{e})
            self.add_trans(pit,pit,self.entries)

    
    ###____ALGORITHME___1__POUR__TP__INF_304___:__RECONNAISSANCE_DE_MOTS_DU_LANGAGE_DONNE___###
    
    def is_in_language(self,u=Word()):
        """Checking wether a give word is recognised by the automaton"""

        q=self.start
        chemin=[]
        prev=q
        count=1

        while count <= u.get_lenght():
            q=self.unit_delta(q,u.symbols[count-1])
            try:
                chemin.append((prev.label,u.symbols[count-1],q.label))
                count+=1
            except AttributeError:
                pass
            prev=q
        if self.is_final(q):
            return [True,chemin]
        else:
            return [False]



class DFA(Automate):
    def __init__(self, s=_Set()):
        super().__init__(s)
    
    def add_trans(self, u_of_edge, v_of_edge=st(), weight={}):
        
        for elt in self.transitions:
            if elt.root == u_of_edge and elt.label == weight:
                raise AutomateException("DFA violation :\nAnother transition with the current root "+str(u_of_edge.label)+" and label already exist in the current object")
        
        super().add_trans(u_of_edge=u_of_edge, v_of_edge=v_of_edge, weight=weight)            

class NDFA(Automate):
    def __init__(self, s=set()):
        super().__init__(s)
    
    def unit_delta(self, state, c) -> set:
        """Elementary transition for NDFA object, \nreturn a set() object containing all the transition destinations"""
        temp=set()
        for elt in self.transitions:
            if elt.root == state and c in elt.label:
                temp.add(elt.dest)
        return temp
    
    
    
    def transit(self,T,c=''):
        """Calcul du transiter """
        transiter=List()

        try:
            for elt in T:
                t=self.unit_delta(elt,c)
                for u in t:
                    transiter.append(u)
        except TypeError:
            t=self.unit_delta(T,c)
            for u in t:
                transiter.append(u)
        return transiter


class eNDFA(NDFA):
    def __init__(self, s=_Set()):
        super().__init__(s)
        s.symbols.add('')
        self.base_set=s
        self.finals=st()
    
    def set_finals(self):
        for elt in self.states:
            if self.is_final(elt):
                self.finals=elt
    
    def glushkov_gen(self,regex=str())-> Automate:
        
        A=eNDFA(self.base_set)
        pattern=Pattern(regex)
        pile=Stacks()
        op_1=eNDFA(self.base_set)
        op_2=eNDFA(self.base_set)

        print(pattern.post_str())
        for re in pattern.postfix:
            if re.prior == retype.CHAR:
                re_node=ReNode(re.str)
                pile.push(auto_char(re_node,self.base_set))
            else:
                if re.prior == retype.UNION:
                    op_2=pile.pop()
                    op_1=pile.pop()
                    A=union(op_1,op_2,self.base_set)
                    pile.push(A)
                    print(A.view_trans())
                elif re.prior == retype.CONCAT:
                    op_2=pile.pop()
                    op_1=pile.pop()
                    A=concat(op_1,op_2,self.base_set)
                    pile.push(A)
                    print(A.view_trans())
                elif re.prior == retype.ITER:
                    op_2=pile.pop()
                    A=iter(op_2,self.base_set)
                    print(A.view_trans())
                    pile.push(A)
        if len(pile) == 1:
            G=pile[0].construct_subset()[4]
            return G        


    def epsilon_closure(self,T):
        """Procedure for building the e-closure of a given set of Automate object states"""

        epsilon=T
        marked=set()
        stack=Stacks()
        for elt in T:
            stack.push(elt)
            marked.add(elt.label)
        
        while not stack.is_empty():
            t=stack.pop()
            unit_closure=self.unit_epsilon_closure(t)
            for u in unit_closure:
                if not list_contain(epsilon,u)[0]:
                    epsilon.append(u)
                    marked.add(u.label)
                    stack.push(u)
        m=List()
        for e in marked:
            m.append(e)
        
        return [epsilon,m]


    def unit_epsilon_closure(self,state):
        """Building the e-closure of a single eNDFA object state"""
        """It proceed in a graph's bfs fashion, with the set delta corresponding to the current 
         node neighbors,but those obtained trough an empty word edge or transition"""
        q=Queue()
        marked_states=set()
        e_potential=List()
        e_potential.append(state)
        delta=set()

        q.enqueue(state)
        marked_states.add(state.label)
        
        while not q.is_empty():
            d=q.dequeue()
            delta=self.unit_delta(d,'')
            
            for elt in delta:
                if elt == None:
                    pass
                else:
                    if not elt.label in marked_states:
                        q.enqueue(elt)
                        marked_states.add(elt.label)
                        e_potential.append(elt)

        return e_potential

    def construct_subset(self):
        """Procedure to built the states list and transitions list
           of a DFA from an eNDFA object"""
        Dstates=List()
        Dtransitions=List()
        Dfa=DFA(self.base_set)

        start=List()
        start.append(self.start)
        Dstates.append(self.epsilon_closure(start)[0])
        dlabels=[]
        dlabels.append(self.epsilon_closure(start)[1])
        dtlabels=[]
        file=Queue()
        file.qset(Dstates[0])
        marked=list()

        for t in file:
            while not list_contain(marked,t)[0]:
                marked.append(t)
                for a in self.entries:
                    u=self.epsilon_closure(self.transit(t,a))[0]
                    v=self.epsilon_closure(self.transit(t,a))[1]
                    if not list_contain(Dstates,u)[0]:
                        Dstates.append(u)
                        dlabels.append(v)
                    
                    if not u == []:
                        Dtransitions.append(tr(t,u,a))
                    file.enqueue(u)
        
        for elt in Dtransitions:
            root=set()
            dest=set()
            for e in elt.root:
                root.add(e.label)
            for i in elt.dest:
                dest.add(i.label)
            dtlabels.append((root,elt.label,dest))

        try:
            dlabels.remove([])
            Dstates.remove([])
        except ValueError:
            pass
        
        ##--Building the corresponding DFA--##
        
        count=0
        marked=List()
        for elt in Dtransitions:
            if not list_contain(marked,elt.root)[0]:
                marked.append(elt.root)
            if not list_contain(marked,elt.dest)[0]:
                marked.append(elt.dest)
        for elt in marked:
            elt.setp(count)
            count=count+1
        for elt in Dtransitions:
            """This use of list_contain function here is a patchwork aplied, 
            due to some unknown misbehavior when using the actual right way"""
            Dfa.add_trans(list_contain(marked,elt.root)[1].getp(),list_contain(marked,elt.dest)[1].getp(),{elt.label})

        for elt in marked:
            for e in elt:
                if e.label == self.finals.label:
                    Dfa.add_trans(elt.getp())
        Dfa.set_start(Dfa.states[0])        

        
        return [Dstates,Dtransitions,dlabels,dtlabels,Dfa]

    def thompson_gen(self,regex=str()) -> Automate:
        A=eNDFA(self.base_set)
        pattern=Pattern(regex)
        pile=Stacks()
        op_1=eNDFA(self.base_set)
        op_2=eNDFA(self.base_set)

        print(pattern.post_str())
        for re in pattern.postfix:
            if re.prior == retype.CHAR:
                re_node=ReNode(re.str)
                pile.push(auto_char(re_node,self.base_set))
            else:
                if re.prior == retype.UNION:
                    op_2=pile.pop()
                    op_1=pile.pop()
                    A=union(op_1,op_2,self.base_set)
                    pile.push(A)
                    print(A.view_trans())
                elif re.prior == retype.CONCAT:
                    op_2=pile.pop()
                    op_1=pile.pop()
                    A=concat(op_1,op_2,self.base_set)
                    pile.push(A)
                    print(A.view_trans())
                elif re.prior == retype.ITER:
                    op_2=pile.pop()
                    A=iter(op_2,self.base_set)
                    print(A.view_trans())
                    pile.push(A)
        
        if len(pile) == 1:
            return pile[0]
        else:
            raise AutomateException("The Thompson procedure ended with wrong result !!!")


global const
const=[]

def auto_char(reg=ReNode(),set=_Set()):
    
    if reg.prior==retype.CHAR:
        char=eNDFA(set)

        const.append('')
        a=st(len(const))
        const.append('')
        b=st(len(const))
        char.add_states_from([a,b])
        char.add_trans(a,b,{reg.str})
        char.add_trans(b)
        
        char.set_start(a)
        char.set_finals()

        return char
    else:
        return None


def union(A=eNDFA(),B=eNDFA(),set=_Set()):

    A.set_finals()
    B.set_finals()
    u=eNDFA(set)

    const.append('')
    a=st(len(const))
    const.append('')
    b=st(len(const))
    
    af=A.get_final_trans()
    bf=B.get_final_trans()
    
    af.dest=b
    bf.dest=b
    af.label={''}
    bf.label={''}

    u.add_trans_from(A.transitions)
    u.add_trans_from(B.transitions)
    u.add_states_from(A.states)
    u.add_states_from(B.states)
    u.add_state(a)
    u.add_state(b)
    u.add_trans(a,A.start,{''})
    u.add_trans(a,B.start,{''})
    u.add_trans(b)
    
    u.set_start(a)
    u.set_finals()

    return u


def concat(A=eNDFA(),B=eNDFA(),set=_Set()):
    A.set_finals()
    B.set_finals()

    const.append('')
    u=eNDFA(set)

    a=st(len(const))
    const.append('')
    b=st(len(const))

    af=A.get_final_trans()
    
    af.dest=B.start
    af.label={''}

    u.add_trans_from(A.transitions)
    u.add_trans_from(B.transitions)
    u.add_states_from(A.states)
    u.add_states_from(B.states)
    u.set_start(A.start)
    u.set_finals()

    return u

    

def iter(A=eNDFA(),set=_Set()):
    A.set_finals()
    u=eNDFA(set)

    const.append('')
    a=st(len(const))
    const.append('')
    b=st(len(const))
    

    af=A.get_final_trans()
    af.dest=b
    af.label={''}
    A.add_trans(af.root,A.start,{''})

    u.add_trans_from(A.transitions)
    u.add_states_from(A.states)
    u.add_state(a)
    u.add_state(b)
    u.add_trans(a,A.start,{''})
    u.add_trans(a,b,{''})
    u.add_trans(b)
    
    u.set_start(a)
    u.set_finals()

    return u 





"""alphabet=_Set({'a','b','c','d','e'})
A=eNDFA(alphabet)
B=A.thompson_gen('a*.b+a.c')
print(B.view_trans())
#print(B.construct_subset()[4].view_trans())

""""""t=[]
for i in range(0,4):
   t.append(st(i))

A.add_trans(t[0],t[1],'')
A.add_trans(t[0],t[0],'a')
A.add_trans(t[1],t[2],'')
A.add_trans(t[1],t[1],'b')
A.add_trans(t[2],t[2],'c')
A.add_trans(t[2])
A.set_start(t[0])
A.set_finals()

G=A.construct_subset()[3]
D=A.construct_subset()[4]
print(G)
D.view_trans()"""