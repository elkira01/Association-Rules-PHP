import networkx as nx
from symbols import Superset


class State:
    def __init__(self,lb='') -> None:
        self.label=lb

    def __str__(self) -> any:
        return self.label

class Transition:
    def __init__(self,u=State(),v=State(),lb=set()):
        super().__init__()
        self.root=u
        self.dest=v
        self.label=lb
        
    def __str__(self) -> str:
        print(self.root)
        print(self.label)
        print(self.dest)
        print('------------')


    def get(self):
        return (self.root,self.dest,self.label)

