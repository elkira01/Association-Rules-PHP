from components import State
from regexp import *
from langage import eNDFA
from components import *
from symbols import _Set

global const
const=[]

def auto_char(reg=ReNode(),set=_Set()):
    
    if reg.prior==retype.CHAR:
        char=eNDFA(set)

        const.append('')
        a=State(len(const))
        const.append('')
        b=State(len(const))
        char.add_states_from([a,b])
        char.add_trans(a,b,{reg.str})
        char.add_trans(b)
        
        char.set_start(a)
        char.set_finals()

        return char
    else:
        return None


def union(A=eNDFA(),B=eNDFA(),set=_Set()):

    A.set_finals()
    B.set_finals()
    u=eNDFA(set)

    const.append('')
    a=State(len(const))
    const.append('')
    b=State(len(const))
    
    af=A.get_final_trans()
    bf=B.get_final_trans()
    
    af.dest=b
    bf.dest=b
    af.label={''}
    bf.label={''}

    u.add_trans_from(A.transitions)
    u.add_trans_from(B.transitions)
    u.add_states_from(A.states)
    u.add_states_from(B.states)
    u.add_state(a)
    u.add_state(b)
    u.add_trans(a,A.start,{''})
    u.add_trans(a,B.start,{''})
    u.add_trans(b)
    
    u.set_start(a)
    u.set_finals()

    return u


def concat(A=eNDFA(),B=eNDFA(),set=_Set()):
    A.set_finals()
    B.set_finals()

    const.append('')
    u=eNDFA(set)

    a=State(len(const))
    const.append('')
    b=State(len(const))

    af=A.get_final_trans()
    
    af.dest=B.start
    af.label={''}

    u.add_trans_from(A.transitions)
    u.add_trans_from(B.transitions)
    u.add_states_from(A.states)
    u.add_states_from(B.states)
    u.set_start(A.start)
    u.set_finals()

    return u
    

def iter(A=eNDFA(),set=_Set()):
    A.set_finals()
    u=eNDFA(set)

    const.append('')
    a=State(len(const))
    const.append('')
    b=State(len(const))
    

    af=A.get_final_trans()
    af.dest=b
    af.label={''}
    A.add_trans(af.root,A.start,{''})

    u.add_trans_from(A.transitions)
    u.add_states_from(A.states)
    u.add_state(a)
    u.add_state(b)
    u.add_trans(a,A.start,{''})
    u.add_trans(a,b,{''})
    u.add_trans(b)
    
    u.set_start(a)
    u.set_finals()

    return u 


#concat(auto_char(ReNode('a'),_Set(set(['a','b']))),auto_char(ReNode('b'),_Set(set(['a','b'])))).view_trans()