from components import *
from data_structure import *
from langage import *
from symbols import _Set,Word
from utils import *
from test_functions import *

choix=''
alphabet=_Set({'a','b','c','d','e'})

if __name__=="__main__":
    print("-------------____TEST TP INFO 304____----------------\n\n")
    print("_________MENU_____________\n\n")
    while(1):
        while(choix!='1' and choix!='2' and choix!='3' and choix !='4'):
            print("\n1-Verifier l'acceptation d'un mot\n\n2-Determinisation des e-Automate\n\n3-Procede de THOMPSON\n\n4-Procede de Glushkov\n\n5-Rendre un automate Complet\n\n")
            choix=input()
        if choix == '3':
            print("\nEntrer une expression reguliere")
            re=input()
            A=eNDFA(alphabet)
            B=eNDFA(alphabet)
            B=A.thompson_gen(re)
            print("\n\nNOMBRE D'ETATS :: "+str(len(B.states))+"\n")
            print("\nEtat initial ::"+str(B.start.label)+"\n\n")
            print("\nEtat final ::"+str(B.finals.label)+"\n\n")
            print("\nTRANSITIONS :\n")
            B.view_trans()
            print("\n1-Verifier l'acceptation d'un mot\n\n2-Determinisation des e-Automate\n\n3-Procede de THOMPSON\n\n4-Procede de Glushkov\n\n5-Rendre un automate Complet\n\n")
            choix=input()
        elif choix == '1':
            C=Automate(alphabet)
            C=build_automate('1',alphabet)
            print("\nListe des Transistions :")
            C.view_trans()
            y='1'
            while True:
                print("\n\nEntrer un mot a reconnaitre ? 0-non 1-oui :\n\n")
                y=input()
                if y == '1':
                    print("Entre :")
                    mot=Word(input(),alphabet)
                    if C.is_in_language(mot)[0]:
                        print("Le mot appartient au langage, chemin parcouru...\n")
                        print(C.is_in_language(mot)[1])
                    else:
                        print("Le mot n'appartient pas au langage ..\n")
                else:
                    break      
            print("\n1-Verifier l'acceptation d'un mot\n\n2-Determinisation des e-Automate\n\n3-Procede de THOMPSON\n\n4-Procede de Glushkov\n\n5-Rendre un automate Complet\n\n")
            choix=input()     
        elif choix == '2':
            print("\n..1-A partir d'une expression reguliere    ..2-Construire l'automate manuellement\n")
            choice=input()
            if choice == '2':
                E=eNDFA(alphabet)
                E=build_epsilon(alphabet)
                D=DFA(alphabet)
                epsilon=E.construct_subset()
                print("\nDeterminisation : \n")
                print("Detats :")
                print(epsilon[2])
                print("\nDtransitions : ")
                print(epsilon[3])
                D=epsilon[4]
                print("\nDeterminise :" )
                D.view_trans()
                print("\n1-Verifier l'acceptation d'un mot\n\n2-Determinisation des e-Automate\n\n3-Procede de THOMPSON\n\n4-Procede de Glushkov\n\n5-Rendre un automate Complet\n\n")
                choix=input()
            elif choice == '1':
                print("\nEntrer une expression reguliere")
                re=input()
                A=eNDFA(alphabet)
                B=eNDFA(alphabet)
                B=A.thompson_gen(re)
                print("\n\nNOMBRE D'ETATS :: "+str(len(B.states))+"\n")
                print("\nEtat initial ::"+str(B.start.label)+"\n\n")
                print("\nEtat final ::"+str(B.finals.label)+"\n\n")
                print("\nTRANSITIONS :\n")
                T=B.construct_subset()
                print("\nDeterminisation : \n")
                print("Detats :")
                print(T[2])
                print("\nDtransitions : ")
                print(T[3])
                D=T[4]
                print("\nDeterminise :" )
                D.view_trans()
                print("\n1-Verifier l'acceptation d'un mot\n\n2-Determinisation des e-Automate\n\n3-Procede de THOMPSON\n\n4-Procede de Glushkov\n\n5-Rendre un automate Complet\n\n")
                choix=input()
            else:
                print("Choix non disponible..")
            print("\n1-Verifier l'acceptation d'un mot\n\n2-Determinisation des e-Automate\n\n3-Procede de THOMPSON\n\n4-Procede de Glushkov\n\n5-Rendre un automate Complet\n\n")
            choix=input()
        elif choix == '5':
            Dfa=Automate()
            while True:
                Dfa=build_automate('1',alphabet)
                if Dfa.is_complete() == True:
                    print("\nL'automate est deja complet ....")
                else:
                    Dfa.set_complete()
                    print("\nAutomate complet ..")
                    Dfa.view_trans()
                    break
            print("\n1-Verifier l'acceptation d'un mot\n\n2-Determinisation des e-Automate\n\n3-Procede de THOMPSON\n\n4-Procede de Glushkov\n\n5-Rendre un automate Complet\n\n")
            choix=input()
        elif choix == '4':
            print("\nEntrer une expression reguliere")
            re=input()
            A=eNDFA(alphabet)
            B=eNDFA(alphabet)
            B=A.glushkov_gen(re)
            print("\n\nNOMBRE D'ETATS :: "+str(len(B.states))+"\n")
            print("\nEtat initial ::"+str(B.start.label)+"\n\n")
            print("\nTRANSITIONS :\n")
            B.view_trans()
            print("\n1-Verifier l'acceptation d'un mot\n\n2-Determinisation des e-Automate\n\n3-Procede de THOMPSON\n\n4-Procede de Glushkov\n\n5-Rendre un automate Complet\n\n")
            choix=input()





