from utils import list_contain
from components import State as st

class Stacks(list):
    def __init__(self) -> None:
        super().__init__()
    
    def pop(self):
        return super().pop(0)
    
    def push(self,__object):
        i=len(self)-1
        self.append(None)
        while i >= 0:
            self[i+1]=self[i]
            i=i-1
        self[0]=__object
    
    def is_empty(self):
        if len(self) == 0:
            return True
        else:
            return False

    def get_heap(self):
        return self[0]
    



class Queue(list):
    def __ini__(self,q='')->None:
        super().__init__()
        for e in q:
            self.append(e)
    
    def qset(self,l=list()):
        self.append(l)

    def enqueue(self,__object):
        i=len(self)-1
        self.append(None)
        while i >= 0:
            self[i+1]=self[i]
            i=i-1
        self[0]=__object
    
    def enqueue_from(self,l):
        for elt in l:
            self.enqueue(elt)
    
    def dequeue(self):
        return super().pop(len(self)-1)
    
    def is_empty(self):
        if len(self) == 0:
            return True
        else:
            return False

class List(list):
    def __init__(self):
        super().__init__()
        self.p=st()
    
    def setp(self,i):
        self.p=st(i)
    
    def getp(self):
        return self.p 

    def is_equal(self,l):
        for elt in l:
            if not list_contain(self,elt):
                return False
        return self

                